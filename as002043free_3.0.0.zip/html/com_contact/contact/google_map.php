<?php

defined('_JEXEC') or die;

?>

<iframe 
width="550" 
height="352" 
frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/?ie=UTF8&amp;t=m&amp;ll=40.579591,-73.970668&amp;spn=0.011082,0.023561&amp;z=15&amp;output=embed"></iframe>