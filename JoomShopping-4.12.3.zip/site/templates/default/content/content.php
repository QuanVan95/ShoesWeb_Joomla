<?php defined('_JEXEC') or die();?>
<div class="jshop jshopcontent" id="comjshop">
<?php print $this->text?>
</div>